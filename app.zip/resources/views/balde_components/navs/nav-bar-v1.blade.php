<nav id="nav_bar" class="z-10 fixe w-full  top-0  fixed  h-16  navbar navbar-expand-lg  
                px-5 py-3 flex flex-row justify-center md:justify-between content-center items-center">
    @include('balde_components.navs.nav-content')
</nav>