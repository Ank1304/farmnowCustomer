    <?php $__env->startSection('title'); ?>
        | <?php echo e(__('About')); ?>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('extraStyle'); ?>
        <link href="<?php echo e(asset('css/help-page.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('content'); ?>
    
        <?php echo $__env->make('balde_components.navs.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <?php echo $__env->make('balde_components.navs.nav-bar-v1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <main class="w-full bg-white" >
            <div class=" w-full  relative flex justify-center  " style="z-index: 0;height: 470px;">
                <img src="/images/faq.jpg" alt="banner" class="absolute w-full h-full object-cover opacity-70 z-0">
                <div class="w-full h-full bg-black"></div>
                <div class="z-10 container  absolute  pt-5 w-11/12 md:w-2/3 flex flex-col justify-center text-center   h-96 ">
                    <h2 class="text-2xl font-bold md:text-6xl text-white my-2">
                        <?php echo e(__("about_banner_header")); ?>

                    </h2>
                    <p class="text-white text-xl font-semibold my-2 ">
                        <?php echo e(__("about_banner_description")); ?>

                    </p>
                    <form class="bg-white h-14 p-2 rounded flex flex-row" action="/search" method="get">
                        <input
                            class="border-white px-2 rounded outline-white flex-1 border-r-2 "
                            name="search"
                            type="search"
                            id="search"
                            placeholder=" <?php echo e(__("Search for markets or products")); ?> ..."
                            required
                            autocomplete="off"
                        >
                        <button class="w-10 text-green" type="submit"> <i class="fas fa-search"></i></button>
                    </form>
                </div>
            </div>
            <faq-help></faq-help>
        </main>
        
        <?php echo $__env->make('balde_components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

    <?php $__env->startSection('extraJs'); ?>
        <script>
            const showArticle=article=>{
                let description=article.querySelector("#desc");
                description.classList.toggle('hidden');
                description.classList.toggle('block');
                let icon = article.querySelector("#icon");
                icon.classList.toggle('fa-plus');
                icon.classList.toggle('fa-minus');
            }
        </script>
    <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u191849931/domains/smartersvision.com/public_html/markets-customer/resources/views/pages/help.blade.php ENDPATH**/ ?>