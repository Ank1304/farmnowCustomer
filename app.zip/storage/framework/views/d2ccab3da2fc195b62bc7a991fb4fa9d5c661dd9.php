<?php $__env->startSection('extraStyle'); ?>
    <link href="<?php echo e(asset('css/checkbox-radio-input.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('balde_components.navs.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('balde_components.navs.nav-bar-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <list-markets :currency_right=<?php echo e(setting('currency_right', false)); ?> :default_currency="`<?php echo e(setting('default_currency')); ?>`"></list-markets>
    <?php echo $__env->make('balde_components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extraJs'); ?>
<script src="<?php echo e(asset('js/maps.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u191849931/domains/smartersvision.com/public_html/markets-customer/resources/views/markets/listing.blade.php ENDPATH**/ ?>