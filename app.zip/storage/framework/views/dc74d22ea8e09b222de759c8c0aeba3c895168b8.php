<nav id="nav_bar" class="z-10 fixe w-full  top-0  fixed  h-16  navbar navbar-expand-lg  
                px-5 py-3 flex flex-row justify-center md:justify-between content-center items-center">
    <?php echo $__env->make('balde_components.navs.nav-content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</nav><?php /**PATH /home/u191849931/domains/smartersvision.com/public_html/markets-customer/resources/views/balde_components/navs/nav-bar-v1.blade.php ENDPATH**/ ?>