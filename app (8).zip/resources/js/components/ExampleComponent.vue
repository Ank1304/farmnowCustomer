<template>
    <div class="container">
         <notifications position="bottom right" width="400px" group="bar" />
    </div>
</template>
