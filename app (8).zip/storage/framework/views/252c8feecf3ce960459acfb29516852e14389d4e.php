<?php $__env->startSection('extraStyle'); ?>
    <link href="<?php echo e(asset('css/confirm-delivery.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/sign-in.css')); ?>" rel="stylesheet">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- side bar -->
    <?php echo $__env->make('balde_components.navs.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                       
    <!-- top nav bar -->
    <?php echo $__env->make('balde_components.navs.nav-bar-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <main class="w-full mt-16 mb-2 flex flex-row justify-center" >
        <div class="container w-4/5 md:w-3/5 lg:w-1/3 mt-3 shadow-2xl p-3  bg-white" style="height:fit-content;" >
            <ul class="nav nav-pills w-full flex flex-row justify-between" id="myTabn" role="tablist">
                <li class="nav-item flex-1" role="presentation">
                    <a class="nav-link custom-btn active text-center mr-2 hover:bg-gray-100 " id="login-tab" data-toggle="tab" href="#login" role="tab" aria-controls="login" aria-selected="true">
                       <?php echo e(__('Login')); ?> 
                    </a>
                </li>
                <li class="nav-item custom-btn flex-1" role="presentation">
                    <a class="nav-link custom-btn text-center mr-2 hover:bg-gray-100 " id="sign-tab" data-toggle="tab" href="#register" role="tab" aria-controls="register" aria-selected="false">
                        <?php echo e(__('Sign in')); ?> 
                    </a>
                </li>
            </ul>
            <div class="tab-content" id="myTabnContent">
                <div class="tab-pane fade show active my-2" id="login" role="tabpanel" aria-labelledby="login-tab">
                    <?php echo $__env->make('auth.forms.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade my-2" id="register" role="tabpanel" aria-labelledby="register-tab">
                    <?php echo $__env->make('auth.forms.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>                                           
        </div>
	</main>
    <?php echo $__env->make('balde_components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<?php $__env->stopSection(); ?>

	
    
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mb1p0x8h3pyz/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>