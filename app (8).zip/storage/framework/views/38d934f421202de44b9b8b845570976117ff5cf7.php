<form class="mt-4"  method="POST" action="/register">
    <?php echo csrf_field(); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-danger">
            <?php echo app('translator')->get(session('status')); ?>
        </div>
    <?php endif; ?>
    
        <div class="text-center my-2 text-black text-md"> 
            <?php echo e(__('Fill the following fields to Sign in')); ?>

        </div>
    
        <div class="mb-3 flex flex-row items-center form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " >
            <label for="name" class="form-label w-1/12 flex flex-row items-center">
                <i class="fas fa-user text-gray-500 mt-2 text-xl <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>text-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></i>
            </label>
            <input 
                id="name" 
                type="text" 
                name="name" 
                value="<?php echo e(old('name')); ?>" 
                required 
                autofocus
                autocomplete="name" 
                placeholder="<?php echo e(__('Enter your full name')); ?>"
                class="outline-none  placeholder-gray-500  flex-1 h-8" 
                >
        </div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-red-500 text-sm -mt-2 mb-2"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    
        <div class="mb-3 flex flex-row items-center form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " >
            <label for="email" class="form-label w-1/12 flex flex-row items-center">
                <i class="fas fa-at text-gray-500 mt-2 text-xl <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>text-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></i>
            </label>
            <input 
                id="email" 
                type="email" 
                name="email" 
                value="<?php echo e(old('email')); ?>" 
                required 
                autofocus 
                autocomplete="email" 
                placeholder="<?php echo e(__('Enter your Email')); ?> "
                class="outline-none placeholder-gray-500 flex-1 h-8"
            >   
        </div>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-red-500 text-sm -mt-2 mb-2"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    
        <div class="mb-3 flex flex-row items-center form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " >
            <label for="password" class="form-label w-1/12 flex flex-row items-center">
                <i class="fas fa-lock text-gray-500 mt-2 text-xl <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>text-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></i>
            </label>
            <input 
                id="password" 
                type="password" 
                name="password"
                required 
                placeholder="<?php echo e(__('Enter your Password')); ?> "
                class="outline-none placeholder-gray-500 flex-1 h-8"
            >   
        </div>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-red-500 text-sm -mt-2 mb-2"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    
        <div class="mb-3 flex flex-row items-center form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " >
            <label for="password_confirmation" class="form-label w-1/12 flex flex-row items-center">
                <i class="fas fa-lock text-gray-500 mt-2 text-xl <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>text-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></i>
            </label>
            <input 
                id="password_confirmation" 
                type="password" 
                name="password_confirmation"
                required 
                placeholder="<?php echo e(__('Confirme your password')); ?> "
                class="outline-none placeholder-gray-500 flex-1 h-8"
            >   
        </div>
    
        <div class="mb-1 text-sm form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1" name="terms">
            <label class="form-check-label text-black" for="exampleCheck1"><?php echo e(__('Terms and Conditions')); ?></label>
        </div>    
    
        <div class="flex flex-row-reverse">
            <button type="submit" class="btn bg-green mb-1 px-5 py-2.5 text-white">
                <?php echo e(__('Submit')); ?>

            </button>
        </div>
    
        <div class="text-center flex justify-between items-center"> 
            <div class="flex-1 h-0.5 bg-gray-300 ml-10 mr-5"></div>
            <div><?php echo e(__('Or')); ?> </div> 
            <div class="mr-10 ml-5 flex-1 h-0.5 bg-gray-300"></div>
        </div>
        <div class="flex flex-col mt-1">
            <a href="/auth/google/register" class="flex-1 flex-row px-2 py-2.5 text-center bg-red-500  my-1 text-white rounded h-14 items-center"><i class="fab fa-google"></i><?php echo e(__('Sign in with google')); ?> </a>
            <a href="/auth/facebook/register" class="flex-1 flex-row px-2 py-2.5 text-center bg-blue-600 my-1 text-white rounded h-14 items-center"><i class="fab fa-facebook"></i> <span class="text-sm md:text-base"><?php echo e(__('Sign in with Facebook')); ?></span></a>
        </div>
    
</form><?php /**PATH /home/mb1p0x8h3pyz/public_html/resources/views/auth/forms/register.blade.php ENDPATH**/ ?>