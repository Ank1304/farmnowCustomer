<?php $__env->startSection('content'); ?>

    <?php $__env->startSection('title'); ?>
        <?php echo $__env->yieldContent('title'); ?>
    <?php $__env->stopSection(); ?>

    <!-- side bar -->
    <?php echo $__env->make('balde_components.navs.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                       
    <!-- top nav bar -->
    <?php echo $__env->make('balde_components.navs.nav-bar-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="flex flex-col justify-center items-center h-screen">
            <div class="text-green font-extrabold text-9xl font-mono my-2">
                <?php echo $__env->yieldContent('code'); ?>
            </div>
            <div class="text-black font-semibold text-lg text-center my-2">
                <?php echo $__env->yieldContent('message'); ?>
            </div>
            <div class="flex flex-row justify-between w-80  my-2" >
                <a href="/" class="nav-link rounded bg-green  h-12 text-white p-3 flex flex-row items-center justify-center text-center">
                    <i class="fas fa-home mx-2 " aria-hidden="true"></i>
                    <?php echo e(__("Home")); ?>

                </a>
                <a href="/contact" class="nav-link rounded border-green h-12 text-green p-3  border-1 flex flex-row items-center justify-center text-center">
                    <i class="fas fa-envelope mx-2 " aria-hidden="true"></i>
                    <?php echo e(__("Contact Us")); ?>

                </a>
            </div>
        </div>
    </div>
    <?php echo $__env->make('balde_components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mb1p0x8h3pyz/public_html/resources/views/errors/minimal.blade.php ENDPATH**/ ?>