<section class="bg-gray-200  py-20 flex flex-col">
    <div class="container">
        <div class="w-full text-center">
            <div class="w-full  self-center content-center flex flex-row justify-center -mt-4 mb-6">
                <p class="border-1 border-green w-44"></p>
            </div>
            <h2 class="text-black text-4xl font-bold py-1">
                <?php echo e(__("popular_categories")); ?>

            </h2>
            <p class="text-gray-600 text-md font-normal  py-1">
                <?php echo e(__("popular_categories_description")); ?>

            </p>
        </div>
        <div class="h-full w-full  slider">
            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/category/<?php echo e($category->id); ?>" class="p-4 nav-link hover:text-green-500 border-white">
                    <div class="relative w-full bg-white rounded shadow-md text-center ">
                        <div class="total absolute top-3 right-3 w-10 h-10 text-sm leading-10 items-center text-black bg-gray-300 rounded-full">
                           
                            +<?php echo e($category->products_count); ?>

                        </div>
                        <div class="flex flex-col h-52 justify-center p-4">
                            <img class="text-green self-center opacity-10 w-50" src="<?php echo e($category->getFirstMediaUrl('image')); ?>" alt="">
                            <b class="mt-2 text-black"><?php echo e($category->name); ?></b> <small class="text-gray-600">
                                <?php if($category->products_avg_price): ?>
                                    <?php echo e(__("avg_price")); ?> <?php echo getPrice($category->products_avg_price); ?>

                                <?php else: ?>
                                    <?php echo e(__("avg_price_is_not_counted")); ?>

                                <?php endif; ?>
                            </small>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH C:\wamp64\www\resources\views/balde_components/popular-categories.blade.php ENDPATH**/ ?>