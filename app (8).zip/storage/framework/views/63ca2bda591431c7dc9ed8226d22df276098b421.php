<?php $__env->startSection('extraStyle'); ?>
<link href="<?php echo e(asset('css/checkbox-radio-input.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- side bar -->
    <?php echo $__env->make('balde_components.navs.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- top nav bar -->
    <?php echo $__env->make('balde_components.navs.nav-bar-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <main class="w-full mt-16 mb-5" >
        <header class="py-3  w-full md:h-24  bg-gray-100 ">
            <div class="container flex flex-col md:flex-row md:justify-between items-center ">
                    <div class="hidden md:block">
                        <div class="text-black text-sm py-1 ">
                            <a href="/" class="hover:text-gray-800 hover:no-underline">
                                <?php echo e(__("Home")); ?>

                            </a> &nbsp; > &nbsp;
                            <a href="#markets" class="text-green hover:no-underline">
                                <?php echo e(__("Markets")); ?>

                            </a> |
                            <a href="#products" class="text-green hover:no-underline">
                                <?php echo e(__("Products")); ?>

                            </a>
                        </div>
                        <p class="text-black font-medium text-lg py-1">
                            <?php echo e(__('Search for markets or products')); ?>

                        </p>
                    </div>

                    <form action="/search" method="get"  class=" w-full h-12 md:w-2/5 md:h-4/6 bg-white flex flex-row rounded ">
                        
                        <input id="search" type="search"  name="search"
                            class="flex-1 bg-white outline-none p-3  rounded-l-sm"
                            placeholder="<?php echo e(__('Search for markets or products')); ?> ..."
                            autocomplete="off"
                            required
                        >
                        <button type="submit" class="w-14 bg-green rounded-r-sm text-white"><i class="fas fa-search"></i></button>
                    </form>
            </div>
        </header>
        <!-- markets -->
        <div class="container w-full flex flex-col pt-4 ">
                <span class="w-40 h-1 bg-green"></span>
                <div class="flex items-center justify-between">
                    <h2 class="text-black font-bold text-4xl pt-4 pb-2">
                        <?php echo e(__("Markets")); ?>

                    </h2>
                    <a id="markets" href="#markets" class="nav-link text-white align-middle text-center bg-green rounded-3xl py-2 px-4 leading-6">
                        <?php echo e(__("Total")); ?> <?php echo e(count($markets)); ?>

                    </a>
                </div>
                <p class="text-gray-400">
                    <?php if($field): ?>
                        <?php echo e(__('Market belong to field')); ?> "<?php echo e($field->name); ?>"
                    <?php else: ?>
                       <?php echo e(__('Search result on markets with a name like')); ?> " <?php echo e($search_value); ?> "
                    <?php endif; ?>
                </p>
        </div>
        <section class="container py-4 w-full flex flex-col lg:flex-row ">
            <div class="w-full mt-3">
                    <div class="grid gap-5 grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4  -mt-1 ">
                       <?php $__empty_1 = true; $__currentLoopData = $markets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div onclick="goToMarket(<?php echo e($market->id); ?>)"  class="box h-64 mt-1 w-full rounded">
                                <div class="h-2/3 w-full relative cursor-pointer">
                                    <?php if($field): ?>
                                        <span class="absolute text-white rounded top-3 left-3  text-sm font-semibold  py-1 px-2 " style="background-color: #333;" >
                                            <?php echo e($field->name); ?>    
                                        </span>
                                    <?php else: ?>
                                        <?php if(count($market->fields)!=0): ?>
                                            <span class="absolute text-white rounded top-3 left-3  text-sm font-semibold  py-1 px-2 " style="background-color: #333;" >
                                                <?php echo e($market->fields->first()->name); ?>

                                            </span>    
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($market->closed): ?>
                                        <span class="absolute text-white rounded top-3 right-3 text-sm font-semibold  py-1 px-2 bg-red-600 ">
                                            closed
                                        </span>
                                    <?php endif; ?>
                                    
                                    <?php if($market->getFirstMediaUrl('image') != ""): ?>
                                        <img src="<?php echo e($market->getFirstMediaUrl('image')); ?>" alt="market" class="h-full w-full rounded ">
                                    <?php else: ?>
                                        <img src="/images/restaurant-placeholder.png" alt="market" class="h-full w-full rounded ">
                                    <?php endif; ?>

                                    <div class="absolute w-full overflow-hidden px-3 py-2.5 bottom-0 flex flex-col justify-center rounded-b-sm" style="background: rgba(92, 92, 92, 0.315);">
                                        <h2 class="text-white text-xl font-semibold truncate">
                                            <?php echo e($market->name); ?>

                                        </h2>
                                        <p class="text-gray-100 text-xs truncate">
                                            <?php echo e($market->address); ?>

                                        </p>
                                    </div>
                                </div>
                                <div class="px-1 py-3 flex flex-row justify-between text-sm w-full">
                                    <span class="text-gray-400 flex-1 h-20 overflow-hidden">
                                        <?php echo $market->description; ?>

                                    </span>
                                    <div class="w-5/12 flex flex-row justify-end ">
                                        <div class="flex flex-col">
                                            <div class="text-gold flex-row flex justify-end items-center ">
                                                <div class="bg-gray-200 py-1 px-2 rounded">
                                                    <span class="text-gray-700 font-semibold">
                                                        <?php echo e($market->rate); ?>

                                                    </span>
                                                    <i class="fas fa-star"></i>
                                                </div>
                                            </div>
                                            <div class="flex-row  flex justify-end items-center mt-1 <?php if($market->available_for_delivery): ?> text-gray-600 <?php else: ?> line-through text-gray-400 <?php endif; ?>">
                                                <?php echo e(__("Delivery")); ?>

                                                <i class="fas fa-motorcycle ml-1"></i>
                                            </div>
                                            <div class="flex-row flex justify-end items-center mt-1 <?php if($market->closed): ?> line-through text-gray-400 <?php else: ?> text-gray-600 <?php endif; ?>">
                                               <?php echo e(__("Take away")); ?>

                                                <i class="fas fa-shopping-basket ml-1"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center font-bold text-3xl col-span-4 h-24 flex flex-row justify-center items-center">
                                <?php echo e(__('No market is found')); ?>

                            </div>
                       <?php endif; ?>
                    </div>
            </div>
        </section>
        
        <div class="container w-full flex flex-col pt-4 ">
            <span class="w-40 h-1 bg-green"></span>
            <div class="flex items-center justify-between">
                <h2 class="text-black font-bold text-4xl pt-4 pb-2">
                    <?php echo e(__("Products")); ?>

                </h2>
                <a id="products" href="#products" class="nav-link text-white align-middle text-center bg-green rounded-3xl py-2 px-4 leading-6">
                    <?php echo e(__("Total")); ?> <?php echo e(count($products)); ?>

                </a>
            </div>
            <p class="text-gray-400">
                <?php if($category): ?>
                    <?php echo e(__('Products belong to category')); ?> "<?php echo e($category->name); ?>"
                <?php else: ?>
                   <?php echo e(__('Search result on products with a name like')); ?> " <?php echo e($search_value); ?> "
                <?php endif; ?>
            </p>
        </div>
        <section class="container py-4 w-full flex flex-col lg:flex-row ">
            <!-- gallery -->
            <div class="w-full mt-3">
                    <div class="grid gap-5 grid-cols-1 md:grid-cols-2 ">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div onclick="goToProduct(<?php echo e($product->market->id); ?>)" class="cursor-pointer box h-44 w-full flex" >
                            <div class="h-full w-1/3">
                        
                                <?php if($product->getFirstMediaUrl('image') != ""): ?>
                                    <img src="<?php echo e($product->getFirstMediaUrl('image')); ?>" alt="product image" class="h-full w-full rounded-l-md object-cover">
                                <?php else: ?>
                                    <img src='/images/food-placeholder.jpeg' alt="product image" class="h-full w-full rounded-l-md object-cover">
                                <?php endif; ?>
                            </div>
                            <div class="flex-1 relative flex flex-col justify-between bg-gray-50 rounded-r-md px-4 pt-4 pb-3">
                                <div class="flex w-full justify-between align-items-start">
                                    <div>
                                        <span class="text-gray-800 ">
                                            <?php echo e($product->category->name); ?>

                                        </span>
                                        <h2 class="text-black text-2xl font-bold ">
                                            <?php echo e($product->name); ?>

                                        </h2>
                                        <p class="text-gray-400 text-sm"><?php echo e($product->market->name); ?></p>
                                        <p class="text-gray-400 text-xs"><?php echo e($product->market->address); ?></p>
                                    </div>
                                    <?php if($product->rate): ?>
                                        <div class="bg-gray-200 py-1 px-2 rounded">
                                            <span class="text-gray-700 font-semibold">
                                                <?php echo e($product->rate); ?>

                                            </span>
                                            <i class="text-gold fas fa-star"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="flex w-full justify-between align-items-baseline">
                                    <div class="flex flex-row items-center">
                                        <p class="text-green text-base font-bold sm py-1 px-2">
                                            <?php echo getPrice($product->getPrice()); ?>

                                        </p>
                                        <?php if($product->discount_price !=0): ?>
                                            <span class="bg-red-600 text-white rounded text-sm py-1 px-2">
                                                -<?php echo e(number_format(100-($product->discount_price * 100 / $product->price),0)); ?> %
                                            </span>
                                        <?php endif; ?>
                                    </div>


                                    <div class="text-sm">
                                        <span class="px-1 <?php if(! $product->market->available_for_delivery): ?> line-through text-gray-400 <?php else: ?> text-gray-600 <?php endif; ?>" >
                                            <?php echo e(__("Delivery")); ?>

                                            <i class="fas fa-motorcycle"></i>
                                        </span>

                                        <span class="px-1 <?php if($product->market->closed): ?> line-through text-gray-400 <?php else: ?> text-gray-600 <?php endif; ?>" >
                                            <?php echo e(__("Take away")); ?>

                                            <i class="fas fa-shopping-basket"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center font-bold text-3xl col-span-4 h-24 flex flex-row justify-center items-center">
                                <?php echo e(__('No product is found')); ?>

                            </div>
                    <?php endif; ?>
                    </div>
            </div>
        </section>
    </main>
    
    <?php echo $__env->make('balde_components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extraJs'); ?>
    <script type="application/javascript">
        function goToProduct(market_id){
            location.href=window.location.origin+'/markets/'+market_id+'#products';
        }
        function  goToMarket(market_id){
            location.href=window.location.origin+'/markets/'+market_id;
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mb1p0x8h3pyz/public_html/resources/views/search_result.blade.php ENDPATH**/ ?>