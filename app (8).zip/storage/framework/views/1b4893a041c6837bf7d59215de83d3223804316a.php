<?php $__env->startSection('extraStyle'); ?>
<link href="<?php echo e(asset('css/checkbox-radio-input.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- side bar -->
    <?php echo $__env->make('balde_components.navs.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- top nav bar -->
    <?php echo $__env->make('balde_components.navs.nav-bar-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="w-full mt-16" >
        <header class="py-3  w-full md:h-24  bg-gray-100 ">
            <div class="container flex flex-col md:flex-row md:justify-between items-center ">
                    <div class="hidden md:block">
                        <div class="text-black text-sm py-1 ">
                            <a href="/" class="hover:text-gray-800 hover:no-underline">
                                <?php echo e(__("Home")); ?>

                            </a> &nbsp; > &nbsp;
                            <a href="#categorys" class="text-gray-800  hover:text-gray-800  hover:no-underline">
                                <?php echo e(__("Categorys")); ?>

                            </a> &nbsp; > &nbsp;
                            <a href="/category/<?php echo e($category->id); ?>" class="text-green hover:text-green-400 hover:no-underline">
                                <?php echo e($category->name); ?>

                            </a>
                        </div>
                        <p class="text-black font-medium text-lg py-1">
                            <?php echo e(__('Search for Markets or Products')); ?>

                        </p>
                    </div>

                    <form action="/search" method="get"  class=" w-full h-12 md:w-2/5 md:h-4/6 bg-white flex flex-row rounded ">
                        
                        <input id="search" type="search"  name="search"
                            class="flex-1 bg-white outline-none p-3  rounded-l-sm"
                            placeholder="<?php echo e(__('Searchfor Markets or Products')); ?> ..."
                            autocomplete="off"
                            required
                        >
                        <button type="submit" class="w-14 bg-green rounded-r-sm text-white"><i class="fas fa-search"></i></button>
                    </form>
            </div>
        </header>

        
        <div class="container w-full flex flex-col pt-4 ">
            <span class="w-40 h-1 bg-green"></span>
            <div class="flex items-center justify-between">
                <h2 class="text-black font-bold text-4xl pt-4 pb-2">
                    <?php echo e(__("Products")); ?>

                </h2>
                <a id="products" href="#categorys" class="btn custom-btn-blue bg-green rounded-3xl py-2 px-4 leading-6">
                    <?php echo e(__("Total")); ?> <?php echo e(count($products)); ?>

                </a>
            </div>
            <p class="text-gray-400">
                <?php echo e(__('Products belong to category')); ?> "<?php echo e($category->name); ?>"
            </p>
        </div>
        <section class="container py-4 w-full flex flex-col lg:flex-row ">
            <!-- gallery -->
            <div class="w-full mt-3">
                <div class="grid gap-5 grid-cols-1 md:grid-cols-2 ">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div  onclick="goToProduct(<?php echo e($product->market->id); ?>)" class="cursor-pointer box h-44 w-full flex" >
                            <div class="h-full w-1/3">
                                <?php if($product->getFirstMediaUrl('image') != ""): ?>
                                    <img src="<?php echo e($product->getFirstMediaUrl('image')); ?>" alt="image" class="h-full w-full rounded-l-md object-cover">
                                <?php else: ?>
                                    <img src='/images/food-placeholder.jpeg' alt="image" class="h-full w-full rounded-l-md object-cover">
                                <?php endif; ?>
                            </div>
                            <div class="flex-1 relative flex flex-col justify-between bg-gray-50 rounded-r-md px-4 pt-4 pb-3">
                                <div class="flex w-full justify-between align-items-start">
                                    <div>
                                        <span class="text-gray-800 ">
                                            <?php echo e($product->category->name); ?>

                                        </span>
                                        <h2 class="text-black text-2xl font-bold ">
                                            <?php echo e($product->name); ?>

                                        </h2>
                                        <p class="text-gray-400 text-sm"><?php echo e($product->market->name); ?></p>
                                        <p class="text-gray-400 text-xs"><?php echo e($product->market->address); ?></p>
                                    </div>
                                    <?php if($product->rate): ?>
                                        <div class="bg-gray-200 py-1 px-2 rounded">
                                            <span class="text-gray-700 font-semibold">
                                                <?php echo e($product->rate); ?>

                                            </span>
                                            <i class="text-gold fas fa-star"></i>
                                        </div>
                                    <?php endif; ?>

                                </div>

                                <div class="flex w-full justify-between align-items-baseline">
                                    <div class="flex flex-row items-center">
                                        <p class="text-green text-base font-bold sm py-1 px-2">
                                            <?php echo getPrice($product->getPrice()); ?>

                                        </p>
                                        <?php if($product->discount_price !=0): ?>
                                                <span class="bg-red-600 text-white rounded text-sm py-1 px-2">
                                                    -<?php echo e(number_format(100-($product->discount_price * 100 / $product->price),0)); ?> %
                                                </span>
                                        <?php endif; ?>
                                        </div>


                                    <div class="text-sm">
                                        <span class="px-1 <?php if(!$product->market->available_for_delivery || $product->market->closed): ?> line-through text-gray-400 <?php else: ?> text-gray-600 <?php endif; ?>" >
                                            <?php echo e(__("Delivery")); ?>

                                            <i class="fas fa-motorcycle"></i>
                                        </span>

                                        <span class="px-1 <?php if($product->market->closed): ?> line-through text-gray-400 <?php else: ?> text-gray-600 <?php endif; ?>" >
                                            <?php echo e(__("Take away")); ?>

                                            <i class="fas fa-shopping-basket"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center font-bold text-3xl col-span-4 h-24 flex flex-row justify-center items-center">
                                <?php echo e(__('No Products is found')); ?>

                            </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        
        <nav aria-label="Page navigation example" class="py-4">
            <ul class="pagination justify-content-center">
                <li class="page-item <?php if($products->onFirstPage()): ?> disabled <?php endif; ?>">
                    <a class="page-link text-green hover:text-green-400" href="<?php echo e($products->previousPageUrl()); ?>" tabindex="-1" aria-disabled="true">
                        <?php echo e(__("Previous")); ?>

                    </a>
                </li>
                <li class="page-item ">
                    <p class="page-link cursor-default text-black hover:text-gray-600 hover:bg-transparent ">
                        <?php echo e(__("Page")); ?> <?php echo e($products->currentPage()); ?>

                        <?php echo e(__("of")); ?> <?php echo e($products->lastPage()); ?>

                    </p>
                </li>

                <li class="page-item  <?php if($products->currentPage() === $products->lastPage()): ?> disabled <?php endif; ?>">
                    <a class="page-link text-green hover:text-green-400 " href="<?php echo e($products->nextPageUrl()); ?>">
                        <?php echo e(__("Next")); ?>

                    </a>
                </li>
            </ul>
        </nav>
    </main>
    
    <?php echo $__env->make('balde_components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extraJs'); ?>
<script type="application/javascript">
    function goToProduct(market_id){
        location.href=window.location.origin+'/markets/'+market_id+'#products';
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mb1p0x8h3pyz/public_html/resources/views/categoryProduct.blade.php ENDPATH**/ ?>